//
//  FriendCell.h
//  SocialSelfie
//
//  Created by Saad Khan on 13/11/2014.
//  Copyright (c) 2014 SocialSelfie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *userStatus;
@property (weak, nonatomic) IBOutlet UIImageView *userPic;

@end
