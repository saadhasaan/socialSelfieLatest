//
//  FriendCell.m
//  SocialSelfie
//
//  Created by Saad Khan on 13/11/2014.
//  Copyright (c) 2014 SocialSelfie. All rights reserved.
//

#import "FriendCell.h"

@implementation FriendCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
