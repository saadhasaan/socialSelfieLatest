//
//  BaseViewController.h
//  SocialSelfie
//
//  Created by Saad Khan on 31/08/2014.
//  Copyright (c) 2014 SocialSelfie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
